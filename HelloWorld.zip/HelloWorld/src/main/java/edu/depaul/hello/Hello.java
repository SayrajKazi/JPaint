/*
 * Class: SE 333 Winter 2021
 * Project: Environment setup
 * Author: Dan Walker
 * Copyright 2020
 */
package edu.depaul.hello;

/**
 * A trivial class to test.  Just verifying that the setup is correct
 */
public class Hello {

  public String greeting(String name) {
    return "Hello, " + name;
  }
}
