/*
 * Class: SE 333 Winter 2021
 * Project: Environment setup
 * Author: Dan Walker
 * Copyright 2020
 */
package edu.depaul.hello;

import org.junit.jupiter.api.Test;

/**
 * Demonstrate that tests do not have to be named **Test
 */
public class NameVerification {

  @Test
  void itRuns() {
    System.out.println("it runs");
  }
}
