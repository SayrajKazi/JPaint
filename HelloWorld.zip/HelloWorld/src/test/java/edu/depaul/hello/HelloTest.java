/*
 * Class: SE 333 Winter 2021
 * Project: Environment setup
 * Author: Dan Walker
 * Copyright 2020
 */
package edu.depaul.hello;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * A simple test class to verify tests are being run
 */
public class HelloTest {

  @Test
  void testSimpleName() {
    String msg = new Hello().greeting("mom");
    assertEquals("Hello, mom", msg);
  }
}
