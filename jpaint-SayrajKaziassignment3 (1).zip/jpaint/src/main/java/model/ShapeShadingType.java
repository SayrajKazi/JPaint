/*
 * Assignment: 1
 * Topic: JPaint
 * Author: Jeffrey Sharpe
 */
package model;

public enum ShapeShadingType {
    FILLED_IN,
    OUTLINE,
    OUTLINE_AND_FILLED_IN
}
