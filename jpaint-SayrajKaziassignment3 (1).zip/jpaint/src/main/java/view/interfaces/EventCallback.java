/*
 * Assignment: 1
 * Topic: JPaint
 * Author: Jeffrey Sharpe
 */
package view.interfaces;

public interface EventCallback {
	void run();
}
