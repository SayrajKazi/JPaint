package view.interfaces;

public interface EventCallback {
	void run();
}
