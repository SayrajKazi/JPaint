package model.interfaces;
import java.awt.Point;
import model.persistence.UserChoicesImpl;

public interface Shape {
    public Point getStartPoint();

    public void SetstartPoint(Point startPoint);

    public Point getendPoint();

    public void setendPoint(Point endPoint);

    public UserChoices userChoices() ;





    public void setAppState(UserChoices userChoiecs) ;

    public int getULeftX();


    public int getULeftY();



    public int getWidth();


    public int getHeight();

    boolean containsPoint(int x, int y);




}


