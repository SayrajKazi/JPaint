package model.picture;

import java.awt.Point;
import.interfaces.Shape;



public class Rectangle {
}
