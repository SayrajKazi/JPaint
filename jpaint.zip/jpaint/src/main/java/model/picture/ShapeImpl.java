package model.picture;

import model.interfaces.UserChoices;

import java.awt.*;

public class ShapeImpl   {
    private final Point start;
    private final Point end;
    private UserChoices userChoices;

    public ShapeImpl(Point start, Point end, UserChoices userChoices, Point end1) {
        this.start = start;
        this.end = end;
        this.userChoices= userChoices;
    }

    public void createShape(Point start, Point end, UserChoices userChoices){
        Shape shape = null;

        if(userChoices.getActiveShapeType().name().equalsIgnoreCase("RECTABGLE")){
            shape = new Rectangle(start, end, userChoices);
        }
        return shape;
    }
}
