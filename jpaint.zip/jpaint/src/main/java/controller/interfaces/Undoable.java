package controller.interfaces;

public interface Undoable {
  void undo();
  void redo();
}
