package controller.interfaces;

public interface Command {
    void run();


}
